Nlista = []
count = 0
quantidade = int(input("Informe a quantiade de número que deseja digitar: "))

while quantidade != count:
    numero = Nlista.append(float(input("Digite um número: ")))
    count += 1

print("Lista: ", Nlista, "\nMaior: ", max(Nlista), "\nMenor: ", min(Nlista))
print("Soma: ", max(Nlista) + min(Nlista))