Nlista = []
count = 0
quantidade = int(input("Informe a quantiade de número que deseja digitar: "))

while quantidade != count:
    numero = float(input("Informe um número: "))

    while numero > 1000 or numero < 0:
        numero = float(input("[erro: Taíoba detectado!!!]Informe um numero entre 0 e 1000: "))

    Nlista.append(numero)
    count += 1

print("Lista: ", Nlista, "\nMaior: ", max(Nlista), "\nMenor: ", min(Nlista))
print("Soma: ", max(Nlista) + min(Nlista))