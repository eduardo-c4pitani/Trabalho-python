s = 0
for a in range(1, 500, 2):
    if a % 3 == 0:
        s += a
print('Soma:', s)