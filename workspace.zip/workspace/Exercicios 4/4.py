print('TABUADA')
n = int(input('Digite um número: '))
for c in range(1, 11):
    print('{} x {} = {}'.format(n, c, n*c))