Nlista = []
count = 0
quantidade = int(input("Informe a quantiade de número que deseja digitar: "))

while quantidade != count:
    numero = float(input("Informe um número: "))
print("\nMaior: ", max(Nlista), "\nMenor: ", min(Nlista))
print('O numero de elementos é: ',len(Nlista))

SomaDosElementos = sum(Nlista)
QuantidadeElemnt = len(Nlista)
media = SomaDosElementos / QuantidadeElemnt
print("Média: ", media )