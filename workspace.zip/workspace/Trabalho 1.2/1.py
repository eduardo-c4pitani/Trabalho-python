numero = int(input("Fatorial de: ") )

resultado=1
count=1

while numero >= count:
    resultado *= count
    count += 1

print(f'O fatorial de {numero} é : {resultado}')
