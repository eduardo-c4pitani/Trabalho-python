Nlista = []
count = 0
quantidade = int(input("Informe a quantiade de número que deseja digitar: "))

while quantidade != count:
    numero = float(input("Informe um número: "))

    while numero > 1000 or numero < 0:
        numero = float(input("[erro: Taíoba detectado!!!]Informe um numero entre 0 e 1000: "))

    Nlista.append(numero)
    count += 1

print("\nMaior: ", max(Nlista), "\nMenor: ", min(Nlista))
print('O numero de elementos é: ',len(Nlista))

SomaDosElementos = sum(Nlista)
QuantidadeElemnt = len(Nlista)
media = SomaDosElementos / QuantidadeElemnt
print("Média: ", media )
