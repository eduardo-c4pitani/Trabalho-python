numero = int(input("Informe um número: "))

if numero % 2 == 0 and numero != 2:
    print("não é primo")
else:
    print("primo")