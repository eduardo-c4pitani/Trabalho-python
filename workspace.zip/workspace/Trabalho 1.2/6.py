numero = int(input("Digite um número: "))
lista = []


if numero % 2 != 0 or numero == 2:
    print("É primo")
else:
    for i in range(numero):
        if numero % (i + 1) == 0:

            lista.append(i + 1)

print("Os números que são divisiveis por: ", numero, " são: ", lista)