numero = int(input("Informe um número: "))
Plista = []
divisoes = 0

for i in range(numero + 1):
    if i % 2 == 1 and i != 2:
        Plista.append(i)
        divisoes += 1
    else:
        divisoes += 1
print("Números primos: ", Plista)
print("Número de divisões", divisoes)
