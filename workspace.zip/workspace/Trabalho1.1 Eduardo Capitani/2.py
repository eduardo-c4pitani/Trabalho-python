#Faça um Programa que peça um número e informe se o número é inteiro ou decimal.
numero = float(input('Digite um numero  :'))

if(numero // 1 == numero):
    print('Número inteiro !')
else:
    print('Número Decimal !')