#Faça um Programa que leia 2 números e em seguida pergunte ao usuário qual operação ele
# deseja realizar. O resultado da operação deve ser acompanhado de uma frase que diga se
# o número é:
#par ou ímpar;
#positivo ou negativo;
#inteiro ou decimal.

val1 = int(input('Informe o primeiro valor: '))
val2 = int(input('Informe o segundo valor: '))

print('Selecione uma das opções?')
opção = int(input('1 - Adição\n2 - Subtração\n3- Multiplicação\n4 - Divisão\n'))

if opção == 1:
    resultado = val1 + val2
elif opção == 2:
    resultado = val1 - val2
elif opção == 3:
    resultado = val1 * val2
elif opção == 4:
    resultado = val1 / val2
else:
    print('Operação invalida')
    exit()

print('Resultado = ', resultado)

if resultado % 2 == 0:
    print('Par')
else:
    print('Impar')

if resultado >= 0:
    print('Positivo')
else:
    print('Negativo')

if type(resultado) == "<class 'int'>":
    print('Inteiro')
else:
    print('Decimal')