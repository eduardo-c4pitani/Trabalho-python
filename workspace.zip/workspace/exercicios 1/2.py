numero= int(input('informe um numero  '))
print(f'O numero informado foi {numero}')