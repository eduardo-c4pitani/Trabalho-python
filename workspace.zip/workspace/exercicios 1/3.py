n1 = int(input('dado 1  '))
n2 = int(input('dado 2  '))
resultado = n1 + n2
print(f'a soma de {n1} mais {n2} é: {resultado}')