
print('Conversão de metros para para centimetros')
M = float(input('Metros  '))
print(f'o valor em cm é: {M*100}')