
r = float(input('informe o raio da circunferência  '))

print(f'A área da cincunferência é: {3.14 * r ** 2}')
