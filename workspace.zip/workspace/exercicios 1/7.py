L = int(input('informe o valor do lado do quadrado   '))
valor = int(L*L)
print(f'A área do quadrado é {valor}')
print(f'sendo assim {valor*2}')

