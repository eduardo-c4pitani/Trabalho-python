N = int(input('informe um numero  '))
print((N - 1), N, (N + 1))