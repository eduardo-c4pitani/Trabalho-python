import math
num = float(input("Informe um número:  "))
raiz = math.sqrt(num)
print(f'A raiz quadrada de {num} é {raiz}')