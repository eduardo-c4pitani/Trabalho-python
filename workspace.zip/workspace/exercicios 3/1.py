def vogal(v):
    if v in "aeiouAEIOU":
        return True
    else:
        return False
print(vogal(input('informe uma letra  ')))