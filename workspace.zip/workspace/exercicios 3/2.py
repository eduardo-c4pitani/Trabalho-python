n1 = float(input('informe a nota 1  '))
n2 = float(input('informe a nota 2  '))
n3 = float(input('informe a nota 3  '))
n4 = float(input('informe a nota 4  '))
media = (n1 + n2 + n3 + n4)/4
if media > 7 or media == 7:
    print(f'Taioba aprovado, média final:{media}')
else:
    print(f'Taioba reprovado, média final:{media}')
