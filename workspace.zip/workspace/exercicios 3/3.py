numero = int(input('informe o primeiro numero'))
numero2 = int(input('informe o segundo numero'))
numero3 = int(input('informe o terceiro numero'))
Maior = 0

if numero > numero2 and numero > numero3:
   Maior = numero
if numero2 > numero and numero2 > numero3:
    Maior = numero2
if numero3 > numero and numero3 > numero2:
    Maior = numero3

print (f'o maior numero é: {Maior}')
