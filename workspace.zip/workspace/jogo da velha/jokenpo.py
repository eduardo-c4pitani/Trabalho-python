from random import randint

lista = ("Pedra", "Papel", "Tesoura")

computador = randint(0, 2)

perguntar = int(input('''[0] Pedra \n[1] Papel \n[2] Tesoura \nEscolha o que vai jogar: '''))

print("O computador escolheu: {}".format(lista[computador]))
print("O jogador escolheu: {}".format(lista[perguntar]))

if computador == 0:
    if perguntar == 0:
        print("Empatado")
    elif perguntar == 1:
        print("Jogador vence")
    elif perguntar == 2:
        print("Computador vence")
    else:
        print("invalido")

elif computador == 1:
    if perguntar == 0:
        print("Computador perde")
    elif perguntar == 1:
        print("Empatado")
    elif perguntar == 2:
        print("Jogador vence")
    else:
        print("invalido")

elif computador == 2:
    if perguntar == 0:
        print("Jogador vence")
    elif perguntar == 1:
        print("Computador vence")
    elif perguntar == 2:
        print("Empatado")
    else:
        print("invalido")

else:
    print("invalido")

print('Se fazer melhor de 3 e perder é um Taióba')